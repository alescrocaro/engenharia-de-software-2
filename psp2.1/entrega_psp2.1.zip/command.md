# How to run the tests

```bash
pytest -v --cov=main test.py
```
